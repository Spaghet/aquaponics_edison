$(function () {

    $('#toggle').click(function () {
        io.emit('toggle');
        console.log("toggle");
    });

    io.on('waterTemp', function (waterTemp) {
        $("#waterTemp").html("Water Temperature: " + waterTemp + 'C');
    });

    io.on('tempHum', function (tempHum) {
        $('#temp').html('Air Temperature: ' + tempHum[0] + 'C');
        $('#hum').html('Humidity: ' + tempHum[1] + '\%');
    });
});